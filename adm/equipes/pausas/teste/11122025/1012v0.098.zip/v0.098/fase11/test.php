<?php
echo "PHP OK";
