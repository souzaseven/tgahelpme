<?php
// ============================================================
// conexao.php - Conexão central com banco (v2.1 Seguro)
// ============================================================

// Impede acesso direto ao arquivo
if (basename($_SERVER['PHP_SELF']) === basename(__FILE__)) {
    http_response_code(403);
    echo json_encode(["erro" => "Acesso direto não permitido."]);
    exit;
}

// ============================================================
// CONFIGURAÇÃO DO AMBIENTE
// ============================================================
$AMBIENTE = "producao"; // "teste" ou "producao"

// ============================================================
// CREDENCIAIS (IDEAL → mover para .env)
// ============================================================
$CREDENCIAIS = [
    "producao" => [
        "host"     => "108.167.151.50",
        "dbname"   => "tgamea80_SUPORTE",
        "user"     => "tgamea80_tgamea80",
        "password" => "anderson@2250"
    ],
    "teste" => [
        "host"     => "localhost",
        "dbname"   => "tga_teste",
        "user"     => "root",
        "password" => ""
    ]
];

$cfg = $CREDENCIAIS[$AMBIENTE];

// ============================================================
// CONEXÃO PDO
// ============================================================
try {
    $pdo = new PDO(
        "mysql:host={$cfg['host']};dbname={$cfg['dbname']};charset=utf8mb4",
        $cfg['user'],
        $cfg['password'],
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET time_zone = '-03:00'"
        ]
    );

} catch (PDOException $e) {

    // Segurança: erro real só em ambiente de teste
    $msgErro = ($AMBIENTE === "teste") ? $e->getMessage() : "Erro interno.";

    http_response_code(500);
    echo json_encode([
        "success" => false,
        "erro"    => "Falha ao conectar ao banco de dados.",
        "detalhe" => $msgErro
    ], JSON_UNESCAPED_UNICODE);

    exit;
}

// ============================================================
// Função utilitária para respostas JSON
// ============================================================
function respostaJSON($array) {
    header("Content-Type: application/json; charset=utf-8");
    echo json_encode($array, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}
?>
