// ============================================================
// login.js — Login por equipe + operador (ATUALIZADO v100)
// ============================================================

document.addEventListener("DOMContentLoaded", () => {

    const elEquipes       = document.getElementById("listaEquipes");
    const elOperadores    = document.getElementById("listaOperadores");

    const stepEquipes     = document.getElementById("stepEquipes");
    const stepOperadores  = document.getElementById("stepOperadores");

    const btnVoltar       = document.getElementById("btnVoltar");
    const btnConfirmar    = document.getElementById("btnConfirmar");
    const erroOperador    = document.getElementById("erroOperador");
    const tituloEquipe    = document.getElementById("tituloEquipe");

    let equipesData       = [];
    let indiceEquipeSel   = null;
    let operadorSel       = null;

    elEquipes.innerHTML = "<p>Carregando equipes...</p>";

    // ============================================================
    // 1) BUSCAR EQUIPES
    // ============================================================
    fetch("../backend/listar_equipes_login.php")
        .then(r => r.json())
        .then(d => {
            if (!d.success || !Array.isArray(d.equipes)) {
                elEquipes.innerHTML = "<p>Falha ao carregar equipes.</p>";
                return;
            }
            equipesData = d.equipes;
            renderizarEquipes();
        })
        .catch(() => {
            elEquipes.innerHTML = "<p>Erro ao carregar equipes.</p>";
        });

    // ============================================================
    // 2) RENDERIZAR EQUIPES
    // ============================================================
    function renderizarEquipes() {
        elEquipes.innerHTML = "";

        equipesData.forEach((eq, index) => {

            const nomeEquipe = eq.nome_equipe || eq.equipe || `Equipe de ${eq.lider}`;
            const lider      = eq.lider || "Líder";

            const div = document.createElement("div");
            div.className = "card-equipe";
            div.innerHTML = `
                <strong>${nomeEquipe}</strong><br>
                <small><i class="fas fa-user-tie"></i> ${lider}</small>
            `;
            div.onclick = () => selecionarEquipe(index);

            elEquipes.appendChild(div);
        });
    }

    // ============================================================
    // 3) SELECIONAR EQUIPE
    // ============================================================
    function selecionarEquipe(indice) {
        indiceEquipeSel = indice;

        const equipe = equipesData[indice];
        const nomeEquipe = equipe.nome_equipe || equipe.equipe || equipe.lider;

        tituloEquipe.textContent = "Equipe: " + nomeEquipe;

        stepEquipes.classList.remove("ativo");
        stepOperadores.classList.add("ativo");

        renderizarOperadores(equipe);
    }

    // ============================================================
    // 4) LISTAR OPERADORES
    // ============================================================
    function renderizarOperadores(eq) {
        elOperadores.innerHTML = "";

        if (!eq.operadores || !eq.operadores.length) {
            elOperadores.innerHTML = "<p>Nenhum operador cadastrado.</p>";
            return;
        }

        eq.operadores.forEach(op => {
            const card = document.createElement("div");
            card.className = "card-operador";
            card.textContent = op.nome;
            card.onclick = () => selecionarOperador(op, card);

            elOperadores.appendChild(card);
        });
    }

    // ============================================================
    // 5) SELECIONAR OPERADOR
    // ============================================================
    function selecionarOperador(op, card) {
        operadorSel = op;

        document.querySelectorAll(".card-operador")
            .forEach(el => el.classList.remove("selecionado"));

        card.classList.add("selecionado");

        btnConfirmar.disabled = false;
        erroOperador.classList.add("oculto");
    }

    // ============================================================
    // 6) BOTÃO VOLTAR
    // ============================================================
    btnVoltar.onclick = () => {
        stepOperadores.classList.remove("ativo");
        stepEquipes.classList.add("ativo");

        operadorSel = null;
        indiceEquipeSel = null;
        btnConfirmar.disabled = true;
    };

    // ============================================================
    // 7) CONFIRMAR LOGIN
    // ============================================================
    btnConfirmar.onclick = async () => {

        if (!operadorSel) {
            erroOperador.classList.remove("oculto");
            return;
        }

        const equipe = equipesData[indiceEquipeSel];
        const nomeEquipe = equipe.nome_equipe || equipe.equipe || equipe.lider;

        const payload = {
            id: operadorSel.id,
            operador: operadorSel.nome,
            equipe: nomeEquipe,
            lider: equipe.lider || null,
            is_admin: operadorSel.is_admin ?? 0,
            ultimoAcesso: new Date().toISOString()
        };

        // Salva no localStorage
        localStorage.setItem("tga_operador", JSON.stringify(payload));

        console.log("[LOGIN] Enviando para definir_online.php:", {
            id: operadorSel.id
        });

        // ========= CHAMADA CORRETA PARA O BACKEND =========
        try {
            const resp = await fetch("../backend/definir_online.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                body: new URLSearchParams({
                    id: operadorSel.id
                })
            });

            const json = await resp.json();
            console.log("[LOGIN] Resposta definir_online.php:", json);

        } catch (e) {
            console.error("[LOGIN] ERRO AO ENVIAR ID PARA definir_online.php:", e);
        }

        // Vai para o painel
        window.location.href = "../painel/index.php";
    };

});
